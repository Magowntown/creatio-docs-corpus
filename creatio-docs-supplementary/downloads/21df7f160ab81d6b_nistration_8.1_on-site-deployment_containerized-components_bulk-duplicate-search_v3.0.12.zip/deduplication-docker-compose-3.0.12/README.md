# creatio deduplication docker compose files

This repository contains the files needed to deploy a duplicate search service in a creatio.
