import type { Config } from 'jest';

export default {
  preset: 'jest-preset-angular',
} satisfies Config;
