﻿using System;
using System.IO;
using System.Net;

namespace WorkWithBpmByWebServices
{
    /// <summary>
    /// Configuration object of the "AuthService.svc" service response body.
    /// </summary>
    class ResponseStatus
    {
        public int Code { get; set; }
        public string Message { get; set; }
        public object Exception { get; set; }
        public object PasswordChangeUrl { get; set; }
        public object RedirectUrl { get; set; }
    }

    /// <summary>
    /// Main program class.
    /// </summary>
    internal class Program
    {

        /* URL of Creatio instance that has the corresponding business processes implemented. */
        private const string baseUri = "https://mycreatio.com";

        /* URL of AuthService.svc service. */
        private const string authServiceUri = baseUri + @"/ServiceModel/AuthService.svc/Login";

        /* URL of ProcessEngineService.svc service. */
        private const string processServiceUri = baseUri + @"/0/ServiceModel/ProcessEngineService.svc/";

        private static ResponseStatus status = null;

        public static CookieContainer AuthCookie = new CookieContainer();

        /// <summary>
        /// Method that authenticates external requests using user credentials.
        /// </summary>
        /// <param name="userName">Login that user uses to log in to Creatio.</param>
        /// <param name="userPassword">Password that user uses to log in to Creatio.</param>
        /// <returns>If the request is authenticated, returns "true." Otherwise, "false."</returns>
        public static bool TryLogin(string userName, string userPassword)
        {
            var authRequest = HttpWebRequest.Create(authServiceUri) as HttpWebRequest;

            /* Request method. */
            authRequest.Method = "POST";

            /* Request header. */
            authRequest.ContentType = "application/json";

            authRequest.CookieContainer = AuthCookie;

            using (var requestStream = authRequest.GetRequestStream())
            {
                using (var writer = new StreamWriter(requestStream))
                {
                    writer.Write(@"{
                    ""UserName"":""" + userName + @""",
                    ""UserPassword"":""" + userPassword + @"""
                    }");
                }
            }

            using (var response = (HttpWebResponse)authRequest.GetResponse())
            {
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    string responseText = reader.ReadToEnd();
                    status = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseStatus>(responseText);
                }
            }

            if (status != null)
            {

                /* If the code contains a "0" value, the authentication is successful. Otherwise, it is failed. */
                if (status.Code == 0)
                {
                    return true;
                }

                Console.WriteLine(status.Message);
            }
            return false;
        }

        /// <summary>
        /// Method that runs a business process of adding a contact.
        /// </summary>
        /// <param name="contactName">Parameter that contains the contact name.</param>
        /// <param name="mobilePhone">Parameter that contains the mobile phone of the contact.</param>
        public static void AddExternalContact(string contactName, string mobilePhone)
        {

            /* Request string.*/
            string requestString = string.Format(processServiceUri + "UsrAddExternalContactProcess/Execute?ContactName={0}&MobilePhone={1}", contactName, mobilePhone);
            HttpWebRequest request = HttpWebRequest.Create(requestString) as HttpWebRequest;

            /* Request method. */
            request.Method = "GET";

            request.CookieContainer = AuthCookie;
            using (var response = request.GetResponse())
            {
                Console.WriteLine(response.ContentLength);
                Console.WriteLine(response.Headers.Count);
            }
        }

        /// <summary>
        /// Method that runs a business process of retrieving the list of contacts.
        /// </summary>
        public static void RetrieveContactList()
        {

            /* Request string.*/
            string requestString = processServiceUri + "UsrRetrieveContactListProcess/Execute?ResultParameterName=ContactList";
            HttpWebRequest request = HttpWebRequest.Create(requestString) as HttpWebRequest;

            /* Request method. */
            request.Method = "GET";

            request.CookieContainer = AuthCookie;
            using (var response = request.GetResponse())
            {
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    string responseText = reader.ReadToEnd();
                    Console.WriteLine(responseText);
                }
            }
        }

        static void Main(string[] args)
        {

            /*  Authenticate external requests using user credentials. */
            if (!TryLogin("SomeCreatioLogin", "SomeCreatioPassword"))
            {
                Console.WriteLine("Wrong login or password. Application will be terminated.");
            }
            else
            {
                try
                {

                    /* Run a business process that adds a contact. */
                    AddExternalContact("James Bennett", "1 111 111 1111");

                    /* Run a business process that retrieves the list of contacts. */
                    RetrieveContactList();
                }
                catch (Exception)
                {
                    /* Process exception here or throw it further. */
                    throw;
                }

            };

            Console.WriteLine("Business processes are run. Press ENTER to exit...");
            Console.ReadLine();
        }
    }
}
