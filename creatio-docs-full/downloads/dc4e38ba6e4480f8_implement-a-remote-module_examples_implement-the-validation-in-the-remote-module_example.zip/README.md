# Example
This project is example of Creatio remote module project.

## Build
Execute command
`npm run build`
and copy *.js files to 8.x package file content.

## Test
Execute command
`npm run test`

## How to develop and consume remote module
You can find different examples by following https://academy.creatio.com link. 