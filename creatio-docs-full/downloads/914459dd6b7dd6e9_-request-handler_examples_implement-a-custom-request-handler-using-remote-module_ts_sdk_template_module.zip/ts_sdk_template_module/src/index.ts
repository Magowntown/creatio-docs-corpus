import {
    BaseRequestHandler,
    CrtModule,
    CrtRequestHandler,
    BaseRequest,
    Logger,
    bootstrapCrtModule,
    DoBootstrap,
} from '@creatio/mobile-common';

@CrtRequestHandler({
	requestType: 'crt.LoadDataRequest',
	type: 'usr.UsrLoadAnyDataRequestHandler',
	scopes: [],
})
export class UsrLoadAnyDataRequestHandler extends BaseRequestHandler {
	public async handle(request: BaseRequest): Promise<unknown> {
		Logger.console('[SDK Demo] Loading any data: ' + request.scopes);
		return this.next?.handle(request);
	}
}

@CrtModule({
    requestHandlers: [
        UsrLoadAnyDataRequestHandler,
    ],
})
export class DevModule implements DoBootstrap {
    bootstrap(): void {
        bootstrapCrtModule('DevModule', DevModule);
    }
}
