﻿using System;
using System.IO;
using System.Net;

namespace AuthenticateExternalRequests
{
    /// <summary>
    /// Configuration object of the "AuthService.svc" service response body.
    /// </summary>
    class ResponseStatus
    {
        public int Code { get; set; }
        public string Message { get; set; }
        public object Exception { get; set; }
        public object PasswordChangeUrl { get; set; }
        public object RedirectUrl { get; set; }
    }

    /// <summary>
    /// Main program class.
    /// </summary>
    internal class Program
    {

        /* URL of Creatio instance that has the corresponding business processes implemented. */
        private const string baseUri = "https://mycreatio.com";

        /* URL of AuthService.svc service. */
        private const string authServiceUri = baseUri + @"/ServiceModel/AuthService.svc/Login";

        private static ResponseStatus status = null;

        public static CookieContainer AuthCookie = new CookieContainer();

        /// <summary>
        /// Method that authenticates external requests using user credentials.
        /// </summary>
        /// <param name="userName">Login that user uses to log in to Creatio.</param>
        /// <param name="userPassword">Password that user uses to log in to Creatio.</param>
        /// <returns>If the request is authenticated, returns "true." Otherwise, "false."</returns>
        public static bool TryLogin(string userName, string userPassword)
        {
            var authRequest = HttpWebRequest.Create(authServiceUri) as HttpWebRequest;

            /* Request method. */
            authRequest.Method = "POST";

            /* Request header. */
            authRequest.ContentType = "application/json";

            authRequest.CookieContainer = AuthCookie;

            using (var requestStream = authRequest.GetRequestStream())
            {
                using (var writer = new StreamWriter(requestStream))
                {
                    writer.Write(@"{
                    ""UserName"":""" + userName + @""",
                    ""UserPassword"":""" + userPassword + @"""
                    }");
                }
            }

            using (var response = (HttpWebResponse)authRequest.GetResponse())
            {
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    string responseText = reader.ReadToEnd();
                    status = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseStatus>(responseText);
                }
            }

            if (status != null)
            {

                /* If the code contains a "0" value, the authentication is successful. Otherwise, it is failed. */
                if (status.Code == 0)
                {
                    return true;
                }

                Console.WriteLine(status.Message);
            }
            return false;
        }

        static void Main(string[] args)
        {

            /*  Authenticate external requests using user credentials. */
            if (!TryLogin("SomeCreatioLogin", "SomeCreatioPassword"))
            {
                Console.WriteLine("Wrong login or password. Application will be terminated.");
            }
            else
            {
                Console.WriteLine("The authentication is successful. External requests to Creatio will be authenticated.");
            };

            Console.WriteLine("Press ENTER to exit...");
            Console.ReadLine();
        }
    }
}