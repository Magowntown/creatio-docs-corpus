/* Import the required functionality from the libraries. */
import {
    BaseRequestHandler,
    CrtModule,
    CrtRequestHandler,
    BaseRequest,
    bootstrapCrtModule,
    DoBootstrap,
    CrtRequest
} from '@creatio/mobile-common';

/* Add the "CrtRequest" decorator to the "ChangeContactTypeToSupplierRequest" class. */
@CrtRequest({
    type: 'usr.ChangeContactTypeToSupplierRequest'
})
export class ChangeContactTypeToSupplierRequest extends BaseRequest {}

/* Add the "CrtRequestHandler" decorator to the "ChangeContactTypeToSupplierRequestHandler" class. */
@CrtRequestHandler({
    requestType: 'usr.ChangeContactTypeToSupplierRequest',
    type: 'usr.ChangeContactTypeToSupplierRequestHandler'
})

export class ChangeContactTypeToSupplierRequestHandler extends BaseRequestHandler<ChangeContactTypeToSupplierRequest> {

    public async handle(request: ChangeContactTypeToSupplierRequest): Promise<unknown> {

        /* Generate the value to display on the Freedom UI page. */
        request.$context['Type'] = 'ac278ef3-e63f-48d9-ba34-7c52e92fecfe';
        return this.next?.handle(request);
    }
}

@CrtModule({
    /* Specify that "ChangeContactTypeToSupplierRequestHandler" is request handler. */
    requestHandlers: [
        ChangeContactTypeToSupplierRequestHandler
    ],
})
export class SdkRemoteModuleInMobileApp implements DoBootstrap {
    bootstrap(): void {
        bootstrapCrtModule('SdkRemoteModuleInMobileApp', SdkRemoteModuleInMobileApp);
    }
}