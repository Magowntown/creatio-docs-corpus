﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System;
	using System.Runtime.Serialization;

	#region Class: BeginTrainingRequest

	/// <summary>
	/// Represent request to machine learning service to start model training.
	/// </summary>
	[DataContract]
	public abstract class BeginTrainingRequest
	{

		#region Properties: Public

		/// <summary>
		/// Gets or sets training session identifier.
		/// </summary>
		[DataMember(Name = "sessionId", IsRequired = true)]
		public Guid SessionId { get; set; }

		#endregion

	}

	#endregion

	#region Class: BeginClassifierTrainingRequest

	/// <summary>
	/// Represent request to machine learning service to start classifier training.
	/// Trained model will be able to solve <see cref="Interfaces.ProblemType.Classification"/> problems.
	/// </summary>
	[DataContract]
	public class BeginClassifierTrainingRequest : BeginTrainingRequest
	{
	}

	#endregion

	#region Class: BeginScorerTrainingRequest

	/// <summary>
	/// Represent request to machine learning service to start scorer training.
	/// Trained model will be able to solve <see cref="Interfaces.ProblemType.PredictiveScoring"/> problems.
	/// </summary>
	[DataContract]
	public class BeginScorerTrainingRequest : BeginTrainingRequest
	{
	}

	#endregion

	#region Class: BeginRegressorTrainingRequest

	/// <summary>
	/// Represent request to machine learning service to start regression training.
	/// Trained model will be able to solve <see cref="ProblemType.Regression"/> problems.
	/// </summary>
	[DataContract]
	public class BeginRegressorTrainingRequest : BeginTrainingRequest
	{
	}

	#endregion

	#region Class: BeginCFTrainingRequest

	/// <summary>
	/// Represents request to machine learning service to start collaborative filtering training.
	/// Trained model will be able to solve <see cref="Interfaces.ProblemType.CollaborativeFiltering"/> problems.
	/// </summary>
	[DataContract]
	public class BeginCFTrainingRequest : BeginTrainingRequest
	{
	}

	#endregion

}
