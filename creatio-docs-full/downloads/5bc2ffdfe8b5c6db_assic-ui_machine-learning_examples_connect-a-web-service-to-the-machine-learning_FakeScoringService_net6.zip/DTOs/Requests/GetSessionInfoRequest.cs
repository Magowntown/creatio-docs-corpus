﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System;
	using System.Runtime.Serialization;

	#region Class: GetSessionInfoRequest

	/// <summary>
	/// Represents request for information about session.
	/// </summary>
	[DataContract]
	public class GetSessionInfoRequest
	{

		#region Properties: Public

		/// <summary>
		/// Gets or sets training session identifier.
		/// </summary>
		[DataMember(Name = "sessionId", IsRequired = true)]
		public Guid SessionId { get; set; }

		#endregion

	}

	#endregion

}
