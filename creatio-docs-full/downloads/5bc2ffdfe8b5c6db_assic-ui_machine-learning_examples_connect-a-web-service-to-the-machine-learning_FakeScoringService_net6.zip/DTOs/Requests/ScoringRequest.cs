﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System.Runtime.Serialization;

	#region Class: ScoringRequest

	/// <inheritdoc />
	/// <summary>
	/// Represents scoring request to machine learning service.
	/// </summary>
	[DataContract]
	public class ScoringRequest : PredictionRequest<DatasetInput>
	{
	}

	#endregion

	#region Class: ExplainedScoringRequest

	/// <summary>
	/// Represents scoring request to machine learning service.
	/// </summary>
	[DataContract]
	public class ExplainedScoringRequest : PredictionRequest<DatasetInput>
	{
	}

	#endregion

}
