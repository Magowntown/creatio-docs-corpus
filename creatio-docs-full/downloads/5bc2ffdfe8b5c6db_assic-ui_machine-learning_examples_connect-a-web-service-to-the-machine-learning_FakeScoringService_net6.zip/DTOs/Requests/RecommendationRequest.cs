﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System.Runtime.Serialization;

	#region Class: RecommendationRequest

	/// <summary>
	/// Describes request to begin recommendation prediction.
	/// </summary>
	[DataContract]
	public class RecommendationRequest : PredictionRequest<RecommendationInput>
	{
	}

	#endregion

}
