﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System;
	using System.Runtime.Serialization;

	#region Class: PredictionRequest

	/// <summary>
	/// Represents base prediction request to machine learning service.
	/// </summary>
	/// <typeparam name="T">Type of prediction input data list.</typeparam>
	/// <seealso cref="T:Terrasoft.ML.Interfaces.Requests.AuthenticatableRequest" />
	[DataContract]
	public class PredictionRequest<TPredictionInput>
	{

		#region Properties: Public

		/// <summary>
		/// Machine learning model instance identifier, that should be used for scoring.
		/// </summary>
		[DataMember(Name = "modelId", IsRequired = true)]
		public Guid ModelId { get; set; }

		/// <summary>
		/// Parameters needed to conduct prediction.
		/// </summary>
		[DataMember(Name = "predictionParams", IsRequired = true)]
		public TPredictionInput PredictionParams { get; set; }

		#endregion

	}

	#endregion

}
