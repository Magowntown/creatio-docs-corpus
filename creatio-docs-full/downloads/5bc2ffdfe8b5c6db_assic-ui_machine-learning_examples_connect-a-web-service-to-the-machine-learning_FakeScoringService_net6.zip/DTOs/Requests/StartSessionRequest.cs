﻿namespace Terrasoft.ML.Interfaces.Requests
{
	using System;
	using System.Runtime.Serialization;

	#region Class: StartSessionRequest

	/// <summary>
	/// Represents handshake request to machine learning service in order to start a model training.
	/// </summary>
	[DataContract]
	public class StartSessionRequest
	{

		#region Properties: Public

		/// <summary>
		/// Gets or sets model schema identifier.
		/// </summary>
		[DataMember(Name = "modelSchemaId", IsRequired = true)]
		public Guid ModelSchemaId { get; set; }

		/// <summary>
		/// Gets or sets model schema metadata.
		/// </summary>
		[DataMember(Name = "modelSchemaMetadata", IsRequired = true)]
		public string ModelSchemaMetadata { get; set; }

		/// <summary>
		/// Gets or sets the session identifier. The parameter is optional: if value is not set new session identifier
		/// will be generated.
		/// </summary>
		[DataMember(Name = "sessionId", IsRequired = false)]
		public Guid SessionId { get; set; }

		#endregion

	}

	#endregion

}
