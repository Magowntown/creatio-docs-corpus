﻿namespace Terrasoft.ML.Interfaces.Responses
{
	using System.Collections.Generic;
	using System.Runtime.Serialization;

	#region Class: RecommendationResponse

	/// <summary>
	/// Describes response for recommendation prediction.
	/// </summary>
	[DataContract]
	public class RecommendationResponse
	{

		#region Properties: Public

		/// <summary>
		/// List of recommendation prediction outcomes.
		/// </summary>
		[DataMember(Name="outputs")]
		public List<RecommendationOutput> Outputs { get; set; }

		#endregion

	}

	#endregion

}
