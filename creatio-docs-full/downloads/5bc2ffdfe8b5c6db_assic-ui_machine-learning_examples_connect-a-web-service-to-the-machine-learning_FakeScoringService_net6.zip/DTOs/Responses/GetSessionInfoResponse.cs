﻿namespace Terrasoft.ML.Interfaces.Responses
{
	using System.Runtime.Serialization;

	#region Class: GetSessionInfoResponse

	/// <summary>
	/// Represents response on <see cref="Requests.GetSessionInfoRequest"/>.
	/// It may contain either session state, if the training is not complete,
	/// or state and <see cref="Interfaces.ModelSummary"/>,
	/// if training is successfully completed.
	/// </summary>
	[DataContract]
	public class GetSessionInfoResponse
	{

		#region Properties: Public

		/// <summary>
		/// Gets or sets session state.
		/// </summary>
		[DataMember(Name = "sessionState", IsRequired = true)]
		public TrainSessionState SessionState { get; set; }

		/// <summary>
		/// Gets or sets the final model summary. This value is present, when training is successfully completed
		/// and <see cref="SessionState"/> is <see cref="TrainSessionState.Done"/>.
		/// </summary>
		[DataMember(Name = "modelSummary", IsRequired = false)]
		public ModelSummary ModelSummary { get; set; }

		/// <summary>
		/// Gets or sets error message. This value is present when session is failed and <see cref="SessionState"/>
		/// is <see cref="TrainSessionState.Error"/>.
		/// </summary>
		[DataMember(Name = "errorMessage", IsRequired = false)]
		public string ErrorMessage { get; set; }

		#endregion

	}

	#endregion

}
