﻿namespace Terrasoft.ML.Interfaces.Responses
{
	using System.Collections.Generic;
	using System.Runtime.Serialization;

	#region Class: ClassificationResponse

	/// <summary>
	/// Represents response from machine learning classification service.
	/// </summary>
	[DataContract]
	public class ClassificationResponse
	{

		#region Properties: Public

		/// <summary>
		/// The collection of classification outputs - one output item per each input item.
		/// </summary>
		[DataMember(Name = "outputs")]
		public List<ClassificationOutput> Outputs { get; set; }

		#endregion

	}

	#endregion

}
