﻿namespace Terrasoft.ML.Interfaces
{

	#region Enum: TrainSessionState

	/// <summary>
	/// Training session state.
	/// </summary>
	public enum TrainSessionState
	{

		/// <summary>
		/// Training hasn't been started.
		/// </summary>
		NotStarted,

		/// <summary>
		/// Data transferring.
		/// </summary>
		DataTransferring,

		/// <summary>
		/// The training is queued.
		/// </summary>
		QueuedToTrain,

		/// <summary>
		/// The training is in progress.
		/// </summary>
		Training,

		/// <summary>
		/// The training is done.
		/// </summary>
		Done,

		/// <summary>
		/// The training is finished with error.
		/// </summary>
		Error
	}

	#endregion

}
