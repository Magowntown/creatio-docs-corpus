﻿namespace Terrasoft.ML.Interfaces
{
	using System;
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.Runtime.Serialization;

	#region Class: ModelSummary

	/// <summary>
	/// Represents result summaries of model fit.
	/// </summary>
	[DataContract]
	public class ModelSummary
	{

		#region Class: FeatureImportance

		/// <summary>
		/// Represents feature importance within a model.
		/// </summary>
		[DataContract]
		[DebuggerDisplay("Name = {Name}; Importance = {Importance}")]
		public class FeatureImportance
		{

			#region Properties: Public

			/// <summary>
			/// Gets or sets feature name.
			/// </summary>
			[DataMember(Name = "feature")]
			public string Name { get; set; }

			/// <summary>
			/// Gets or set feature importance.
			/// </summary>
			[DataMember(Name = "importance")]
			public double Importance { get; set; }

			#endregion

		}

		#endregion

		#region Properties: Public

		/// <summary>
		/// Gets or sets model metric type. Metric determines the model quality of fit.
		/// Model type depends on problem type. It may be "Accuracy" for classification or
		/// "RMSE" (Root mean squared error) for regression problem.
		/// </summary>
		[DataMember(Name = "metricType", IsRequired = true)]
		public string MetricType { get; set; }

		/// <summary>
		/// Gets or sets the model metric value - the value that determines the quality of fit.
		/// </summary>
		[DataMember(Name = "metric", IsRequired = true)]
		public double Metric { get; set; }

		/// <summary>
		/// Gets or sets the size of data set on which model is trained.
		/// </summary>
		[DataMember(Name = "trainSetSize", IsRequired = false, EmitDefaultValue = false)]
		public int DataSetSize { get; set; }

		/// <summary>
		/// Gets or sets the trained model instance identifier.
		/// </summary>
		[DataMember(Name = "modelInstanceUId", IsRequired = true)]
		public Guid ModelInstanceUId { get; set; }

		/// <summary>
		/// Gets or sets the model training time, measured in minutes, ceiled to the nearest integer.
		/// </summary>
		[DataMember(Name = "trainingTimeMinutes", IsRequired = false, EmitDefaultValue = false)]
		public int TrainingTimeMinutes { get; set; }

		/// <summary>
		/// Gets or sets feature importances in a model.
		/// </summary>
		[DataMember(Name = "featureImportances", IsRequired = false, EmitDefaultValue = false)]
		public List<FeatureImportance> FeatureImportances { get; set; }

		/// <summary>
		/// Gets or sets additional information about the model instance.
		/// </summary>
		[DataMember(Name = "rawData", IsRequired = false, EmitDefaultValue = false)]
		public string RawData { get; set; }

		#endregion

	}

	#endregion

}
