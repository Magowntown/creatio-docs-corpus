﻿namespace Terrasoft.ML.Interfaces
{
	using System.Runtime.Serialization;

	#region Class: PredictionInput

	/// <summary>
	/// Represents the input for prediction algorithms.
	/// </summary>
	[DataContract]
	public abstract class PredictionInput
	{

		#region Properties: Public

		/// <summary>
		/// Show feature contributions to final result.
		/// </summary>
		[DataMember(Name = "predictContributions")]
		public bool PredictContributions { get; set; }

		#endregion

	}

	#endregion

}
