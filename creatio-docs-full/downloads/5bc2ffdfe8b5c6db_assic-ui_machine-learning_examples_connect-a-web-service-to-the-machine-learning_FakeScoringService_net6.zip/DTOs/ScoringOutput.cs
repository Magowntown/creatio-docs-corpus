﻿namespace Terrasoft.ML.Interfaces
{
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.Runtime.Serialization;

	#region Class: ScoringOutput

	/// <summary>
	/// Represents the output from scoring algorithm.
	/// </summary>
	[DebuggerDisplay("Score = {Score}; Bias = {Bias}; Contributions Count = {Contributions.Count}")]
	public class ScoringOutput
	{

		#region Class: FeatureContribution

		/// <summary>
		/// Represents contribution of each individual feature to final prediction.
		/// </summary>
		[DataContract]
		[DebuggerDisplay("Name = {Name}; Value = {Value}; Contribution = {Contribution}")]
		public class FeatureContribution
		{

			#region Properties: Public

			/// <summary>
			/// Gets or sets feature name.
			/// </summary>
			[DataMember(Name = "feature")]
			public string Name { get; set; }

			/// <summary>
			/// Gets or sets feature value.
			/// </summary>
			[DataMember(Name = "value")]
			public string Value { get; set; }

			/// <summary>
			/// Gets or set feature contribution to final score.
			/// </summary>
			[DataMember(Name = "contribution")]
			public double Contribution { get; set; }

			#endregion

		}

		#endregion

		/// <summary>
		/// Gets or sets predicted scores for each input record.
		/// </summary>
		[DataMember(Name = "score")]
		public double Score { get; set; }

		/// <summary>
		/// Gets or sets model bias.
		/// </summary>
		[DataMember(Name = "bias", IsRequired = false, EmitDefaultValue = false)]
		public double Bias { get; set; }

		/// <summary>
		/// Gets or sets contributions of each individual feature for every input record.
		/// </summary>
		[DataMember(Name = "contributions", IsRequired = false, EmitDefaultValue = false)]
		public List<FeatureContribution> Contributions { get; set; }

	}

	#endregion

}
