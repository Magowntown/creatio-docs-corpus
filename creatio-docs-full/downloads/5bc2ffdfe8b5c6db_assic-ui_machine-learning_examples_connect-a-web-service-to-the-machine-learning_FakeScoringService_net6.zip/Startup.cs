namespace FakeScoring
{
	using System.Reflection;
	using Microsoft.AspNetCore.Builder;
	using Microsoft.AspNetCore.Hosting;
	using Microsoft.Extensions.Configuration;
	using Microsoft.Extensions.DependencyInjection;
	using Microsoft.Extensions.Hosting;
	using Newtonsoft.Json;
	using Newtonsoft.Json.Converters;

	public class Startup
	{
		public Startup(IConfiguration configuration) {
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		public void ConfigureServices(IServiceCollection services) {
			var mvcBuilder = services.AddControllers();
			// Use this to deserize correctly List<Dictionary<string, object>> from Creatio
			mvcBuilder.AddNewtonsoftJson(options => {
				options.SerializerSettings.DateFormatHandling = DateFormatHandling.IsoDateFormat;
				options.SerializerSettings.Converters.Add(new StringEnumConverter());
				options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
			});
			services.AddOpenApiDocument(settings => {
				settings.Title = "Machine Learning example";
				settings.Version = Assembly.GetExecutingAssembly().GetName().Version.ToString();
			});
		}

		public void Configure(IApplicationBuilder app, IWebHostEnvironment env) {
			if (env.IsDevelopment()) {
				app.UseDeveloperExceptionPage();
			}
			//app.UseHttpsRedirection();
			app.UseRouting();
			app.UseAuthorization();
			app.UseEndpoints(endpoints => {
				endpoints.MapControllers();
			});
			app.UseOpenApi();
			app.UseSwaggerUi3();
		}
	}
}
