﻿namespace FakeScoring.Controllers
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Net;
	using Microsoft.AspNetCore.Mvc;
	using Terrasoft.ML.Interfaces;
	using Terrasoft.ML.Interfaces.Requests;
	using Terrasoft.ML.Interfaces.Responses;

	[ApiController]
	[Route("")]
	public class MLService : Controller
	{
		public const string FakeModelInstanceUId = "{BFC0BD71-19B1-47B1-8BC4-D761D9172667}";

		private List<ScoringOutput.FeatureContribution> GenerateFakeContributions(DatasetValue record) {
			var random = new Random(42);
			return record.Select(columnValue => new ScoringOutput.FeatureContribution {
				Name = columnValue.Key,
				Contribution = random.NextDouble(),
				Value = columnValue.Value.ToString()
			}).ToList();
		}

		[HttpGet("ping")]
		public JsonResult Ping() {
			return new JsonResult("Ok");
		}

		/// <summary>
		/// Handshake request to service with the purpose to start a model training session.
		/// </summary>
		/// <param name="request">Instance of <see cref="StartSessionRequest"/>.</param>
		/// <returns>Instance of <see cref="StartSessionResponse"/>.</returns>
		[HttpPost("session/start")]
		public StartSessionResponse StartSession(StartSessionRequest request) {
			return new StartSessionResponse {
				SessionId = Guid.NewGuid()
			};
		}

		/// <summary>
		/// Uploads training data.
		/// </summary>
		/// <param name="request">The upload data request.</param>
		/// <returns>Instance of <see cref="JsonResult"/>.</returns>
		[HttpPost("data/upload")]
		public JsonResult UploadData(UploadDataRequest request) {
			return new JsonResult(string.Empty) {
				StatusCode = (int)HttpStatusCode.OK
			};
		}

		/// <summary>
		/// Begins fake scorer training on uploaded data.
		/// </summary>
		/// <param name="request">The scorer training request.</param>
		/// <returns>Simple <see cref="JsonResult"/>.</returns>
		[HttpPost("fakeScorer/beginTraining")]
		public JsonResult BeginScorerTraining(BeginScorerTrainingRequest request) {
			// Start training work here. It doesn't have to be done by the end of this request.
			return new JsonResult(string.Empty) {
				StatusCode = (int)HttpStatusCode.OK
			};
		}

		/// <summary>
		/// Returns current session state and model statistics, if training is complete.
		/// </summary>
		/// <param name="request">Instance of <see cref="GetSessionInfoRequest"/>.</param>
		/// <returns>Instance of <see cref="GetSessionInfoResponse"/> with detailed state info.</returns>
		[HttpPost("session/info/get")]
		public GetSessionInfoResponse GetSessionInfo(GetSessionInfoRequest request) {
			var response = new GetSessionInfoResponse {
				SessionState = TrainSessionState.Done,
				ModelSummary = new ModelSummary {
					DataSetSize = 100500,
					Metric = 0.79,
					MetricType = "Accuracy",
					TrainingTimeMinutes = 5,
					ModelInstanceUId = new Guid(FakeModelInstanceUId)
				}
			};
			return response;
		}

		/// <summary>
		/// Performs fake scoring prediction.
		/// </summary>
		/// <param name="request">Request object.</param>
		/// <returns>Scoring rates.</returns>
		[HttpPost("fakeScorer/predict")]
		public ScoringResponse Predict(ExplainedScoringRequest request) {
			List<ScoringOutput> outputs = new List<ScoringOutput>();
			var random = new Random(42);
			foreach (var record in request.PredictionParams.Data) {
				var output = new ScoringOutput {
					Score = random.NextDouble()
				};
				if (request.PredictionParams.PredictContributions) {
					output.Bias = 0.03;
					output.Contributions = GenerateFakeContributions(record);
				}
				outputs.Add(output);
			}
			return new ScoringResponse { Outputs = outputs };
		}
	}
}
